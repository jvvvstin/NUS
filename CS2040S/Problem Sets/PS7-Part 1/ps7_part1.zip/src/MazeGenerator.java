public class MazeGenerator {

	private MazeGenerator() { }

	// TODO: Feel free to modify the method parameters.
	public static Maze generateMaze(int rows, int columns) {
		return null;
	}
}
