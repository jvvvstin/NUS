
public class Solution {
    public static int solve(int[] arr, int target) {
        // TODO: Implement your solution here

        return 0;
    }
}
