import java.util.ArrayList;

public class BellmanFord {
    // DO NOT MODIFY THE TWO STATIC VARIABLES BELOW
    public static int INF = 20000000;
    public static int NEGINF = -20000000;

    // TODO: add additional attributes and/or variables needed here, if any

    public BellmanFord(ArrayList<ArrayList<IntPair>> adjList) {
        // TODO: initialize your attributes here, if any
    }

    // TODO: add additional methods here, if any

    public int getDistance(int node) { 
        // TODO: implement your getDistance operation here
        return 0;
    }

}
