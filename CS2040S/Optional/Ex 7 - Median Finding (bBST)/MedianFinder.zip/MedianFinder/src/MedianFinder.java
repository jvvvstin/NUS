import java.util.TreeMap;
import java.util.TreeSet;

public class MedianFinder {

    // TODO: Include your data structures here

    public MedianFinder() {
        // TODO: Construct/Initialise your data structures here
    }

    public void insert(int x) {
        // TODO: Implement your insertion operation here
    }

    public int getMedian() {
        // TODO: Implement your getMedian operation here

        return 0;
    }


}
