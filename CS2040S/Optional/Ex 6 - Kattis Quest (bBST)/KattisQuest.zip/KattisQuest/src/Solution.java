public class Solution {
    // TODO: Include your data structures here

    public Solution() {
        // TODO: Construct/Initialise your data structures here
    }

    void add(long energy, long value) {
        // TODO: Implement your insertion operation here
    }

    long query(long remainingEnergy) {
        // TODO: Implement your query operation here

        return 0L;
    }

}
