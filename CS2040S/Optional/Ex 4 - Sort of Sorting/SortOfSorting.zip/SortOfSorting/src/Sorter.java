class Sorter {

    public static void sortStrings(String[] arr) {
        // TODO: implement your sorting function here
    }
}
