import java.util.HashMap;
import java.util.Hashtable;

public class Solution {
    // TODO: Implement your solution here
    public static int solve(int[] arr) {
        int maxLength = -1;

        return maxLength;
    }
}