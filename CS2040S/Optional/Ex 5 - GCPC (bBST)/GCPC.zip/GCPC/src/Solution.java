
public class Solution {
    // TODO: Include your data structures here


    public Solution(int numTeams) {
        // TODO: Construct/Initialise your data structures here
    }

    public int update(int team, long newPenalty){
        // TODO: Implement your update function here
        return 0;
    }

}
